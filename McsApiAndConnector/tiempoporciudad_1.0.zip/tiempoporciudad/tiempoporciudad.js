module.exports = function(service) {
	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */
	service.get('/mobile/custom/TiempoPorCiudad/:ciudad', function(req,res) {
		
			var sdk = req.oracleMobile;
			
			//Obtenemos el valor parametro del request
			var ciudad = req.params.ciudad;
			
			//URI del connector
			var optionsList={uri: '/mobile/connector/Tiempo'};

			//Parametros del connector
			var queryObject={};
			queryObject.q=ciudad;
			optionsList.qs=queryObject;

			sdk.rest.get(optionsList, function(error,response,body)
			{
				if (error)
				{
					res.send(response,error.message);
				}
				else
				{
					res.send(200, body);
				}
			});
	});
};


